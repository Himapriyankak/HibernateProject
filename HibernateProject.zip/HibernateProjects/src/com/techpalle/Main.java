package com.techpalle;



import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.techpalle.Model.Employee;

public class Main {

	public static void main(String[] args) {
		// load the session factory
		SessionFactory sf = new Configuration().configure().buildSessionFactory();
		//open session
		Session  s = sf.openSession();
		//begin transcation
		Transaction t = s.beginTransaction();
		
		// C- Creating rows into the tables
		Employee e = new Employee(1, "steave", 10000,"dev");
		Employee e1 = new Employee(2,"bill",20000,"dev");
	    Employee e2 = new Employee(3,"andy",30000,"hr");
	    s.save(e);
	    s.save(e1);
	    s.save(e2); 
	    
	    // R - Reading the rows from the table
	    Employee x = s.get(Employee.class,2);
		System.out.println(x.getEno());
		System.out.println(x.getEname());
		System.out.println(x.getEsal());
		System.out.println(x.getEdesg()); 
		
		// U - Updating the rows from the table
	    Employee y = s.get(Employee.class, 1);
	    y.setEsal(15000);
	    s.save(y);
	    
	    // D - Deleting the row from the table
	    Employee z = s.get(Employee.class, 3);
	    s.delete(z);
		t.commit();
		s.close();
		sf.close();

	}

}
